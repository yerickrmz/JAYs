package database;

public class UserData {    
    public boolean validate(String email, String password) {
        return (email.equals("wendy.ramirez@ucrso.info") && password.equals("123"));
    }    
}
